﻿using BankPro.Data.Configurations;
using BankPro.Data.Entities;
using Microsoft.EntityFrameworkCore;

namespace BankPro.Data
{
    public class BankProDbContext : DbContext
    {
        public DbSet<LoanLead> LoanLeads { get; set; }

        public DbSet<Address> Addresses { get; set; }

        public DbSet<User> Users { get; set; }


        public BankProDbContext(DbContextOptions options) : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfiguration(new LoanLeadConfiguration());
            modelBuilder.ApplyConfiguration(new UserConfiguration());
        }
    }
}