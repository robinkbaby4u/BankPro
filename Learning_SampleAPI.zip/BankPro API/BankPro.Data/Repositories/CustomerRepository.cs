﻿using BankPro.Data.Entities;
using BankPro.Data.Interfaces;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;

namespace BankPro.Data.Repositories
{
    public class CustomerRepository : ICustomerRepository
    {
        private readonly BankProDbContext _dbContext;

        public CustomerRepository(BankProDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public User GetUser(int userId)
        {
            return _dbContext.Users.Where(x => x.Id.Equals(userId)).FirstOrDefault();
        }

        /// <summary>
        /// Save all user detailsto database
        /// </summary>
        /// <param name="user">User etails</param>
        /// <returns>Save status</returns>
        public async Task<bool> SaveUser(User user)
        {
            _dbContext.Entry(user).State = EntityState.Added;
            int affectedRows = await _dbContext.SaveChangesAsync();

            return affectedRows > 0;
        }
    }
}