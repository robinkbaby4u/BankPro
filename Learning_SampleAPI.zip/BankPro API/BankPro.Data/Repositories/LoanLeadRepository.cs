﻿using BankPro.Data.Entities;
using BankPro.Data.Interfaces;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BankPro.Data.Repositories
{
    public class LoanLeadRepository : ILoanLeadRepository
    {
        private readonly BankProDbContext _dbContext;

        public LoanLeadRepository(BankProDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        /// <summary>
        /// Get all card type details
        /// </summary>
        /// <returns>List of card types</returns>
        public async Task<IEnumerable<LoanLead>> GetLoanLeads(int customerId)
        {
            return await _dbContext.LoanLeads.Where(x=>x.ContactId.Equals(customerId)).ToListAsync();
        }

        /// <summary>
        /// Create Loan lead
        /// </summary>
        /// <param name="loanLead"></param>
        /// <returns></returns>
        public async Task<bool> CreateLoanLead(LoanLead loanLead)
        {
            _dbContext.Entry(loanLead).State = EntityState.Added;
            int affectedRows = await _dbContext.SaveChangesAsync();

            return affectedRows > 0;
        }

        /// <summary>
        /// Update Loan Lead
        /// </summary>
        /// <param name="loanLead"></param>
        /// <returns></returns>
        public async Task<bool> UpdateLoanLead(LoanLead loanLead)
        {
            _dbContext.Entry(loanLead).State = EntityState.Modified;
            int affectedRows = await _dbContext.SaveChangesAsync();

            return affectedRows > 0;
        }
    }
}