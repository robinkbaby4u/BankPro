﻿using BankPro.Data.Entities;
using System.Threading.Tasks;

namespace BankPro.Data.Interfaces
{
    public interface ICustomerRepository
    {
        /// <summary>
        /// Save all user detailsto database
        /// </summary>
        /// <param name="user">User Enquiry details</param>
        /// <returns>Save status</returns>
        Task<bool> SaveUser(User user);

        User GetUser(int userId);
    }
}