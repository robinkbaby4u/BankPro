﻿using BankPro.Data.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace BankPro.Data.Interfaces
{
    public interface ILoanLeadRepository
    {
        /// <summary>
        /// Get all Loan Leads
        /// </summary>
        /// <returns></returns>
        Task<IEnumerable<LoanLead>> GetLoanLeads(int customerId);

        /// <summary>
        /// Create Loan lead
        /// </summary>
        /// <param name="loanLead"></param>
        /// <returns></returns>
        Task<bool> CreateLoanLead(LoanLead loanLead);

        /// <summary>
        /// Update Loan lead
        /// </summary>
        /// <param name="loanLead"></param>
        /// <returns></returns>
        Task<bool> UpdateLoanLead(LoanLead loanLead);
    }
}