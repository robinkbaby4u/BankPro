﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BankPro.Data.Entities
{
    public class LoanLead
    {
        /// <summary>
        /// Lead Id
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Loan Amount
        /// </summary>
        public int LoanAmount { get; set; }

        /// <summary>
        /// Lead Source
        /// </summary>
        public string LeadSource { get; set; }

        /// <summary>
        /// Communication Mode
        /// </summary>
        public string CommunicationMode { get; set; }

        /// <summary>
        /// Current Status
        /// </summary>
        public string CurrentStatus { get; set; }

        /// <summary>
        /// Contact Id
        /// </summary>
        public int ContactId { get; set; }
    }
}
