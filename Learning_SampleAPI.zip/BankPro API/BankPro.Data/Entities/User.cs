﻿using System;

namespace BankPro.Data.Entities
{
    public class User
    {
        /// <summary>
        /// User Id
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// First Name
        /// </summary>
        public string FirstName { get; set; }

        /// <summary>
        /// Last Name
        /// </summary>
        public string LastName { get; set; }

        /// <summary>
        /// Date Of Birth
        /// </summary>
        public DateTime DateOfBirth { get; set; }

        /// <summary>
        /// Contact Name
        /// </summary>
        public string ContactName { get; set; }

        /// <summary>
        /// Email Id
        /// </summary>
        public string EmailId { get; set; }

        /// <summary>
        /// Gender
        /// </summary>
        public Gender Gender { get; set; }

        /// <summary>
        /// Address Id
        /// </summary>
        public int AddressId { get; set; }

        /// <summary>
        /// Contact Type Id
        /// </summary>
        public ContactType ContactType { get; set; }

        /// <summary>
        /// Primary Phone
        /// </summary>
        public string PrimaryPhone { get; set; }

        /// <summary>
        /// Alternate Phone
        /// </summary>
        public string AlternatePhone { get; set; }
    }

    public enum ContactType
    {
        Individual,
        MediumEnterprise,
        LargeEnterprise

    }

    public enum Gender
    {
        Male,
        Female,
        Others
    }
}