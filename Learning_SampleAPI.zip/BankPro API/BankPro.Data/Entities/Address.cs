﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BankPro.Data.Entities
{
    public class Address
    {
        /// <summary>
        /// Address Id
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Address Line 1
        /// </summary>
        public string AddressLine1 { get; set; }

        /// <summary>
        /// Address Line 2
        /// </summary>
        public string AddressLine2 { get; set; }

        /// <summary>
        /// Address Line 3
        /// </summary>
        public string AddressLine3 { get; set; }

        /// <summary>
        /// Address Line 4
        /// </summary>
        public string AddressLine4 { get; set; }


    }
}
