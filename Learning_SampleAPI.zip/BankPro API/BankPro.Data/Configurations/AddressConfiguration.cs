﻿using BankPro.Data.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;

namespace BankPro.Data.Configurations
{
    public class AddressConfiguration : IEntityTypeConfiguration<Address>
    {
        public void Configure(EntityTypeBuilder<Address> builder)
        {
            builder.ToTable("Address");
            builder.Property(x => x.Id).ValueGeneratedOnAdd();
            builder.Property(x => x.AddressLine1).IsRequired();
            builder.Property(x => x.AddressLine2).IsRequired();
            builder.Property(x => x.AddressLine3);
            builder.Property(x => x.AddressLine4);
        }
    }
}
