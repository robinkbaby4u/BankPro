﻿using BankPro.Data.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace BankPro.Data.Configurations
{
    public class UserConfiguration : IEntityTypeConfiguration<User>
    {
        public void Configure(EntityTypeBuilder<User> builder)
        {
            builder.ToTable("User");
            builder.Property(x => x.Id).ValueGeneratedOnAdd();
            builder.Property(x => x.FirstName).IsRequired();
            builder.Property(x => x.LastName).IsRequired();
            builder.Property(x => x.DateOfBirth).IsRequired();
            builder.Property(x => x.ContactName).IsRequired();
            builder.Property(x => x.AddressId).IsRequired();
            builder.Property(x => x.PrimaryPhone).IsRequired();
            builder.Property(x => x.AlternatePhone);
            builder.Property(x => x.ContactType).IsRequired();
            builder.Property(x => x.EmailId).IsRequired();
            builder.Property(x => x.Gender).IsRequired();
        }
    }
}