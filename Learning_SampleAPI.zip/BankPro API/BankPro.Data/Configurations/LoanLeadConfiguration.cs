﻿using BankPro.Data.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace BankPro.Data.Configurations
{
    public class LoanLeadConfiguration : IEntityTypeConfiguration<LoanLead>
    {
        public void Configure(EntityTypeBuilder<LoanLead> builder)
        {
            builder.ToTable("LeadInformation");
            builder.Property(x => x.Id).ValueGeneratedOnAdd();
            builder.Property(x => x.CommunicationMode).IsRequired();
            builder.Property(x => x.ContactId).IsRequired();
            builder.Property(x => x.CurrentStatus).IsRequired();
            builder.Property(x => x.LeadSource);
            builder.Property(x => x.LoanAmount).IsRequired();
        }
    }
}
