﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BankPro.Controllers
{
    [Route("api/home")]
    [ApiController]
    public class HomeController : ControllerBase
    {
        // GET: HomeController
        public async Task<IActionResult> Get()
        {
            return Ok();
        }

        // GET: HomeController/Details/5
        public ActionResult Details(int id)
        {
            return Ok();
        }

        // GET: HomeController/Create
        public ActionResult Create()
        {
            return Ok();
        }       
    }
}
