﻿using BankPro.Attributes;
using BankPro.Business.Commands;
using BankPro.Business.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Threading.Tasks;

namespace BankPro.Controllers
{
    [Route("api/customer")]
    [ServiceFilter(typeof(TokenValidationAttribute))]
    [ApiController]
    public class CustomerController : ControllerBase
    {
        private ILogger _logger { get; set; }
        private ICustomerService _customerService { get; set; }

        public CustomerController(ICustomerService customerService, ILogger logger)
        {
            _customerService = customerService;
            _logger = logger;
        }

        public async Task<IActionResult> Get(int customerId)
        {
            try
            {
                return Ok(await _customerService.GetCustomerDetails(customerId));
            }
            catch (Exception ex)
            {
                _logger.Log(LogLevel.Error, "An error occured during Customer creation: " + ex.Message);
                return StatusCode(500);
            }
        }

        [HttpPost]
        public async Task<IActionResult> Post([FromBody] CustomerCommand customerCommand)
        {
            try
            {
                return Ok(await _customerService.CreateCustomer(customerCommand));
            }
            catch (Exception ex)
            {
                _logger.Log(LogLevel.Error, "An error occured during Customer creation: " + ex.Message);
                return StatusCode(500);
            }
        }

    }
}
