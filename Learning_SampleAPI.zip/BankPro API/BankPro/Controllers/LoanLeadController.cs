﻿using BankPro.Attributes;
using BankPro.Business.Commands;
using BankPro.Business.Interfaces;
using BankPro.Business.Responses;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace BankPro.Controllers
{
    [Route("api/leads")]
    [ServiceFilter(typeof(TokenValidationAttribute))]
    [ApiController]
    public class LoanLeadController : ControllerBase
    {
        private ILogger _logger { get; set; }

        private ILoanLeadService _loanLeadService { get; set; }

        public LoanLeadController(ILoanLeadService loanLeadService, ILogger logger)
        {
            _loanLeadService = loanLeadService;
            _logger = logger;
        }

        // GET: api/<LoanLeadController>/5
        [HttpGet("{customerId}")]
        public async Task<ActionResult> Get(int customerId)
        {
            try
            {
                return Ok(await _loanLeadService.GetLoanLeads(customerId));
            }
            catch (Exception ex)
            {
                _logger.Log(LogLevel.Error, "An error occured while getting Loan leads: " + ex.Message);
                return StatusCode(500);
            }
        }

        //// GET api/<LoanLeadController>
        //[HttpGet]
        //public string Get()
        //{
        //    return "value";
        //}

        // POST api/<LoanLeadController>
        [HttpPost]
        public async Task<ActionResult> PostAsync([FromBody] LoanLeadCommand loanLeadCommand)
        {
            try
            {
                return Ok(await _loanLeadService.CreateLoanLead(loanLeadCommand));
            }
            catch (Exception ex)
            {
                _logger.Log(LogLevel.Error, "An error occured during Loan Lead creation: " + ex.Message);
                return StatusCode(500);
            }
        }

        // PUT api/<LoanLeadController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/<LoanLeadController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
