﻿using System;
using System.Text.Json.Serialization;

namespace BankPro.Business.Responses
{
    public class CustomerResponse
    {
        /// <summary>
        /// Contact Name
        /// </summary>
        [JsonPropertyName("contactName")]
        public string ContactName { get; set; }

        /// <summary>
        /// Contact Type
        /// </summary>
        [JsonPropertyName("contactType")]
        public ContactType ContactType { get; set; }

        /// <summary>
        /// Date Of Birth
        /// </summary>
        [JsonPropertyName("dateOfBirth")]
        public DateTime DateOfBirth { get; set; }

        /// <summary>
        /// Gender
        /// </summary>
        [JsonPropertyName("gender")]
        public Gender Gender { get; set; }

        /// <summary>
        /// Email Id
        /// </summary>
        [JsonPropertyName("emailId")]
        public string EmailId { get; set; }

        /// <summary>
        /// Primary Contact Number
        /// </summary>
        [JsonPropertyName("primaryContactNumber")]
        public string PrimaryContactNumber { get; set; }

        /// <summary>
        /// Alternate Contact Number
        /// </summary>
        [JsonPropertyName("alternateContactNumber")]
        public string AlternateContactNumber { get; set; }
    }

    public enum Gender
    {
        Male,
        Female,
        Others
    }
    public enum ContactType
    {
        Individual,
        MediumEnterprise,
        LargeEnterprise

    }
}