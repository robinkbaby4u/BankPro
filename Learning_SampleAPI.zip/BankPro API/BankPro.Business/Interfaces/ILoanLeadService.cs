﻿using BankPro.Business.Commands;
using BankPro.Business.Responses;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace BankPro.Business.Interfaces
{
    public interface ILoanLeadService
    {
        Task<List<LoanLeadResponse>> GetLoanLeads(int customerId);

        Task<bool> CreateLoanLead(LoanLeadCommand loanLeadCommand);

        Task<bool> UpdateLoanLead(LoanLeadCommand loanLeadCommand);
    }
}
