﻿using BankPro.Business.Commands;
using BankPro.Business.Responses;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace BankPro.Business.Interfaces
{
    public interface ICustomerService
    {
        Task<CustomerResponse> GetCustomerDetails(int customerId);

        Task<bool> CreateCustomer(CustomerCommand customerCommand);
    }
}
