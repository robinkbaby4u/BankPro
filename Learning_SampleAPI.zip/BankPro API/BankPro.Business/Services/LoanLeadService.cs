﻿using BankPro.Business.Commands;
using BankPro.Business.Interfaces;
using BankPro.Business.Responses;
using BankPro.Data.Entities;
using BankPro.Data.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace BankPro.Business.Services
{
    public class LoanLeadService : ILoanLeadService
    {
        private ILoanLeadRepository _loanLeadRepository { get; set; }

        public LoanLeadService(ILoanLeadRepository loanLeadRepository)
        {
            _loanLeadRepository = loanLeadRepository;
        }

        public async Task<List<LoanLeadResponse>> GetLoanLeads(int customerId)
        {
            IEnumerable<LoanLead> loanLeads = await _loanLeadRepository.GetLoanLeads(customerId);
            List<LoanLeadResponse> loanLeadResponses = new List<LoanLeadResponse>();

            foreach(LoanLead loanLead in loanLeads )
            {
                LoanLeadResponse loanleadResponse = new LoanLeadResponse()
                {
                    CommunicationMode=loanLead.CommunicationMode,
                    ContactId= loanLead.ContactId,
                    CurrentStatus=loanLead.CurrentStatus,
                    Id=loanLead.Id,
                    LeadSource=loanLead.LeadSource,
                    LoanAmount=loanLead.LoanAmount
                };

                loanLeadResponses.Add(loanleadResponse);
            }

            return loanLeadResponses;
        }

        public async Task<bool> CreateLoanLead(LoanLeadCommand loanLeadCommand)
        {
            LoanLead loanLead = new LoanLead()
            {
                CommunicationMode = loanLeadCommand.CommunicationMode,
                ContactId = loanLeadCommand.ContactId,
                CurrentStatus = loanLeadCommand.CurrentStatus,
                LeadSource = loanLeadCommand.LeadSource,
                LoanAmount = loanLeadCommand.LoanAmount
            };

            return await _loanLeadRepository.CreateLoanLead(loanLead);
        }

        public async Task<bool> UpdateLoanLead(LoanLeadCommand loanLeadCommand)
        {
            LoanLead loanLead = new LoanLead()
            {
                Id = loanLeadCommand.Id,
                CommunicationMode = loanLeadCommand.CommunicationMode,
                ContactId = loanLeadCommand.ContactId,
                CurrentStatus = loanLeadCommand.CurrentStatus,
                LeadSource = loanLeadCommand.LeadSource,
                LoanAmount = loanLeadCommand.LoanAmount
            };

            return await _loanLeadRepository.UpdateLoanLead(loanLead);
        }
    }
}
