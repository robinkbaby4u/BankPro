﻿using BankPro.Business.Commands;
using BankPro.Business.Interfaces;
using BankPro.Business.Responses;
using BankPro.Data.Entities;
using BankPro.Data.Interfaces;
using System.Threading.Tasks;

namespace BankPro.Business.Services
{
    public class CustomerService : ICustomerService
    {
        public ICustomerRepository _customerRepository { get; set; }

        public CustomerService(ICustomerRepository customerRepository)
        {
            _customerRepository = customerRepository;
        }

        public Task<CustomerResponse> GetCustomerDetails(int userId)
        {
            User user = _customerRepository.GetUser(userId);
            CustomerResponse customerResponse = null;

            if (user != null)
            {
                customerResponse = new CustomerResponse()
                {
                    AlternateContactNumber = user.AlternatePhone,
                    ContactName = user.ContactName,
                    ContactType = (Responses.ContactType)user.ContactType,
                    DateOfBirth = user.DateOfBirth,
                    EmailId = user.EmailId,
                    Gender = (Responses.Gender)user.Gender,
                    PrimaryContactNumber = user.PrimaryPhone
                };
            }

            return Task.FromResult(customerResponse);
        }

        public Task<bool> CreateCustomer(CustomerCommand customerCommand)
        {
            User user = new User()
            {
                AddressId = customerCommand.AddressId,
                AlternatePhone = customerCommand.AlternatePhone,
                ContactName = customerCommand.ContactName,
                ContactType = (Data.Entities.ContactType)customerCommand.ContactType,
                DateOfBirth = customerCommand.DateOfBirth,
                EmailId = customerCommand.EmailId,
                FirstName = customerCommand.FirstName,
                Gender = (Data.Entities.Gender)customerCommand.Gender,
                LastName = customerCommand.LastName,
                PrimaryPhone = customerCommand.PrimaryPhone
            };

            return _customerRepository.SaveUser(user);
        }
    }
}
