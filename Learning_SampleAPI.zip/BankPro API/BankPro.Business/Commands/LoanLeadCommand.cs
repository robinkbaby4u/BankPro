﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json.Serialization;

namespace BankPro.Business.Commands
{
    public class LoanLeadCommand
    {
        /// <summary>
        /// Id
        /// </summary>
        [JsonPropertyName("id")]
        public int Id { get; set; }

        /// <summary>
        /// Loan Amount
        /// </summary>        
        [JsonPropertyName("loanAmount")]
        public int LoanAmount { get; set; }

        /// <summary>
        /// Lead Source
        /// </summary>
        [JsonPropertyName("leadSource")]
        public string LeadSource { get; set; }

        /// <summary>
        /// Communication Mode
        /// </summary>
        [JsonPropertyName("communicationMode")]
        public string CommunicationMode { get; set; }

        /// <summary>
        /// Current Status
        /// </summary>
        [JsonPropertyName("currentStatus")]
        public string CurrentStatus { get; set; }

        /// <summary>
        /// Contact Id
        /// </summary>
        [JsonPropertyName("contactId")]
        public int ContactId { get; set; }
    }
}
