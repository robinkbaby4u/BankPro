﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json.Serialization;

namespace BankPro.Business.Commands
{
    public class CustomerCommand
    {
        /// <summary>
        /// User Id
        /// </summary>
        [JsonPropertyName("id")]
        public int Id { get; set; }

        /// <summary>
        /// First Name
        /// </summary>
        [JsonPropertyName("firstName")]
        public string FirstName { get; set; }

        /// <summary>
        /// Last Name
        /// </summary>
        [JsonPropertyName("lastName")]
        public string LastName { get; set; }

        /// <summary>
        /// Date Of Birth
        /// </summary>
        [JsonPropertyName("dateOfBirth")]
        public DateTime DateOfBirth { get; set; }

        /// <summary>
        /// Contact Name
        /// </summary>
        [JsonPropertyName("contactName")]
        public string ContactName { get; set; }

        /// <summary>
        /// Email Id
        /// </summary>
        [JsonPropertyName("emailId")]
        public string EmailId { get; set; }

        /// <summary>
        /// Gender
        // </summary>
        [JsonPropertyName("gender")]
        public Gender Gender { get; set; }

        /// <summary>
        /// Address Id
        /// </summary>
        [JsonPropertyName("addressId")]
        public int AddressId { get; set; }

        /// <summary>
        /// Contact Type Id
        /// </summary>
        [JsonPropertyName("contactType")]
        public ContactType ContactType { get; set; }

        /// <summary>
        /// Primary Phone
        /// </summary>
        [JsonPropertyName("primary Phone")]
        public string PrimaryPhone { get; set; }

        /// <summary>
        /// Alternate Phone
        /// </summary>
        [JsonPropertyName("alternatePhone")]
        public string AlternatePhone { get; set; }
    }

    public enum ContactType
    {
        Individual,
        MediumEnterprise,
        LargeEnterprise

    }

    public enum Gender
    {
        Male,
        Female,
        Others
    }
}
